package serializacao.naoserializaveis.heranca.painaoserializavel;


public class Animal{

	protected double altura;
	protected double peso;

	public Animal() {
		super();
		System.out.println("Animal");
	}

}