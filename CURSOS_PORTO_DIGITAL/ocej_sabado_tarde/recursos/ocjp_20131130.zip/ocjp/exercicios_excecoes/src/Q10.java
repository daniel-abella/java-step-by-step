Q:10 Given:
33. try {
34. // some code here
35. } catch (NullPointerException e1) {
36. System.out.print("a");
37. } catch (RuntimeException e2) {
38. System.out.print("b");
39. } finally {
40. System.out.print("c");
41. }
What is the result if a NullPointerException occurs on line 34?
A. c
B. a
C. ab
D. ac
E. bc
F. abc
Answer: D





























