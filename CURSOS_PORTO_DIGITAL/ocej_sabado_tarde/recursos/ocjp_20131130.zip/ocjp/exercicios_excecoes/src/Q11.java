Q:11 Given:
10. public class Foo {
11. static int[] a;
12. static { a[0]=2; }
13. public static void main( String[] args ) {}
14. }
Which exception or error will be thrown when a programmer attempts to run this code?
A. java.lang.StackOverflowError
B. java.lang.IllegalStateException
C. java.lang.ExceptionInInitializerError
D. java.lang.ArrayIndexOutOfBoundsException
Answer: C



















