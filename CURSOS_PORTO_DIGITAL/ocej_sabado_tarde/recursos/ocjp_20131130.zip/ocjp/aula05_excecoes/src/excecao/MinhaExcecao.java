package excecao;

/**
 * [CRIAÇÃO]
 * @author miguelangelo
 *
 */
public class MinhaExcecao extends Exception {

	public MinhaExcecao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MinhaExcecao(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public MinhaExcecao(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MinhaExcecao(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
