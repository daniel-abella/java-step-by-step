package modelo;

import excecao.MinhaExcecao;

public class Modelo {

	/*
	 * DECLARAR
	 */
	public void fazAlgo() throws MinhaExcecao{

		//.........

		/*
		 * LEVANTAR
		 */
		throw new MinhaExcecao("Deu bronca !!!!! Toma que é tua !");
	}
}
