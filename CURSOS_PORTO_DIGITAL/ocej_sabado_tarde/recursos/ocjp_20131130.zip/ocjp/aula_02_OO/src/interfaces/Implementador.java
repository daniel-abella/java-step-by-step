package interfaces;

import java.io.Serializable;

public class Implementador implements Serializable, Cloneable, Auditavel{

	private static final long serialVersionUID = 1L;

	@Override
	public String getDetalhes() {
		// TODO Auto-generated method stub
		return null;
	}

}
