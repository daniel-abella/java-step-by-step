package interfaces;

public interface Auditavel {

	String getDetalhes();
}
