package sobrescrita;

import java.io.IOException;

public class Pai {

	protected Number getNumber() throws IOException{
		return null;
	}

	public int getInt(){
		return 0;
	}

	public long getLong(){
		return 0;
	}
}
