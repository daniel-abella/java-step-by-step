package contrutor;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstrutorNeto construtorNeto = new ConstrutorNeto();
		System.out.println("**************************************");
		System.out.println("**************************************");
		construtorNeto = new ConstrutorNeto("chamada direta" );
		//System.out.println(construtorNeto);
	}

}
