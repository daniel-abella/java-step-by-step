package contrutor;

public class ConstrutorFilho extends Construtor {

	public ConstrutorFilho(){
		super("aaaaaaaaaaaaaaaa");
		System.out.println("ConstrutorFilho.ConstrutorFilho()");
//		String nullString = null;
//		nullString.charAt(0);
	}
}
