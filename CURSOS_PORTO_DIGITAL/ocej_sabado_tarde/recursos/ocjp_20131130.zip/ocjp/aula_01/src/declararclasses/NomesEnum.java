package declararclasses;

public enum NomesEnum {
	NOME_01, NOME_02, NOME_03, NOME_04, NOME_05, NOME_06, NOME_07, NOME_08, NOME_09;
}