package declararclasses;

public interface Nomes {

	String NOME_01 = "NOME_01";
	String NOME_02 = "NOME_02";
	String NOME_03 = "NOME_03";
	String NOME_04 = "NOME_04";
	String NOME_05 = "NOME_05";
	String NOME_06 = "NOME_06";
	String NOME_07 = "NOME_07";
	String NOME_08 = "NOME_08";
	String NOME_09 = "NOME_09";
}
