package referencia;

public class Usuario {

	private String login;

	public Usuario(String login) {
		this.login = login;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

//	@Override
//	public String toString() {
//		return "Usuario [login=" + login + "]";
//	}
}
