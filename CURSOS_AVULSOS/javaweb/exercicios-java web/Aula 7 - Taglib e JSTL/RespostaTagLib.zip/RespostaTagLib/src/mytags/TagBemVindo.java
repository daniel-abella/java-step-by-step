package mytags;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspTagException;
import java.io.*;

public class TagBemVindo extends TagSupport {

  private String cpf;

  public int doStartTag() throws JspTagException {
      try {
          pageContext.getOut().write("Hello world.<br>"+cpf);

      } catch (IOException ex) {
          throw new JspTagException
                  ("Fatal error: hello tag could not write to JSP out");
      }
      return SKIP_BODY;
  }
  public int doEndTag() throws JspTagException {
      return EVAL_PAGE;
  }

  public String getCpf() {
    return cpf;
  }

  public void setCpf(String cpf) {
    this.cpf = cpf;
  }

}