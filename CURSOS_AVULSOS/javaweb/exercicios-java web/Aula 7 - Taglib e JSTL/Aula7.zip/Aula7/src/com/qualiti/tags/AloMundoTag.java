package com.qualiti.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

public class AloMundoTag extends TagSupport {
	  private String texto;

	  public int doStartTag() throws JspTagException {
	      try {
	          pageContext.getOut().write("Mensagem Recebida: "+texto);

	      } catch (IOException ex) {
	          throw new JspTagException
	                  ("Fatal error: hello tag could not write to JSP out");
	      }
	      return SKIP_BODY;
	  }
	  public int doEndTag() throws JspTagException {
	      return EVAL_PAGE;
	  }

	  public String getTexto() {
	    return texto;
	  }

	  public void setTexto(String texto) {
	    this.texto = texto;
	  }

}
