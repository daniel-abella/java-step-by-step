package beans;

public class TextoBean {

	private String texto;
	
	public String getTexto() {
		return texto;
	}
	
	public void setTexto(String texto) {
		this.texto = texto;
	}
	
	public String enviar() {
		if (texto.trim().equals("")){
			return "erro";
		}
		//enviar para algum lugar
		return "sucesso";

	}
}
