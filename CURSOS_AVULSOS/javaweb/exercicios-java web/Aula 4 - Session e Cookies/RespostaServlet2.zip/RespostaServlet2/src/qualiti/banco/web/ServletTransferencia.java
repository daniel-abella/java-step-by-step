package qualiti.banco.web;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import qualiti.banco.contas.*;
import qualiti.banco.clientes.*;
import qualiti.banco.fachada.*;

public class ServletTransferencia extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html";
    //Initialize global variables
    public void init() throws ServletException {
    }
    //Process the HTTP Get request
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
    //Process the HTTP Post request
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Fachada fachada = Fachada.obterInstancia();

        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>ServletTransferencia</title></head>");
        out.println("<body>");
        out.println("<h1>Internet Banking</h1><hr><br>");
        Cliente cliente=null;
        try {
            HttpSession session = request.getSession(false);
            cliente = (Cliente)session.getAttribute("cliente");
            if (cliente==null) throw new Exception("Acesso negado!");
            String sorigem = request.getParameter("tx_origem");
            String sdestino = request.getParameter("tx_destino");
            String svalor = request.getParameter("tx_valor");

            ContaAbstrata origem;
            ContaAbstrata destino;
            double valor;
            origem = fachada.procurarConta(sorigem);
            if (!origem.getCliente().getCpf().equals(cliente.getCpf()))
                throw new Exception("Conta no. "+sorigem+" n�o pertence ao cliente "+ cliente.getNome()+"!");
            destino = fachada.procurarConta(sdestino);
            valor = Double.parseDouble(svalor);
            if (valor<0)
                throw new Exception("Valor "+svalor+" inv�lido!");
            if (origem.getSaldo()<valor)
                throw new Exception("Saldo insuficiente!");

            fachada.transferir(sorigem, sdestino, valor);
            out.println("Opera��o realizada com sucesso!");
        }
        catch (Exception ex) {
            out.println("Opera��o n�o concluida.<br>Motivo: "+ex.getMessage());
            ex.printStackTrace();
        }
        if (cliente!=null)
            out.println("<br><br><a href=\"ServletLoginCliente\">Voltar</a>");
        else
            out.println("<br><br><a href=\"loginCliente.html\">Voltar</a>");

        out.println("</body></html>");
    }
    //Clean up resources
    public void destroy() {
    }
}