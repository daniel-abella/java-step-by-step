package qualiti.banco.web;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import qualiti.banco.fachada.Fachada;
import qualiti.banco.clientes.Cliente;

public class ServletLoginCliente extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html";

    //Initialize global variables
    public void init() throws ServletException {
    }

    //Process the HTTP Get request
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    //Process the HTTP Post request
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Fachada fachada = Fachada.obterInstancia();
        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("<HTML><BODY>");
        try {
            Cliente c = null;
            HttpSession session = request.getSession(true);
            if(request.getMethod().equals("POST")) {
                // Pesquisa o cliente
                String cpf = request.getParameter("tx_cpf");
                c = fachada.procurarCliente(cpf);
                // Coloca o cliente na sess�o

                session.setAttribute("cliente", c);
            } else {
                c = (Cliente)session.getAttribute("cliente");
            }
            // Exibe o menu
            out.println("<h1>Internet Banking</h1><hr>");
            out.println("<p>Bem vindo(a) " + c.getNome() + "</p>");
            out.println("<ul>"+
                        "<li><a href=\"ServletListarContas\">Listar Contas</a></li>"+
                        "<li><a href=\"criarconta.html\">Criar conta</a></li>"+
                        "<li><a href=\"transferencia.html\">Transfer�ncia entre contas</a></li>"+
                        "</ul>"
                        );
        } catch (Exception ex) {
            out.print("CPF inv�lido!<br><a href=\"loginCliente.html\">Tente novamente!</a>");
        }
        out.println("</BODY></HTML>");
    }
    //Clean up resources
    public void destroy() {
    }
}