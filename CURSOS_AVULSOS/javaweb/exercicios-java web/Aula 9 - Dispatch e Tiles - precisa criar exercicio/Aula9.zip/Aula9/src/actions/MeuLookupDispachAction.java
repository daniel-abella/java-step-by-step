package actions;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.LookupDispatchAction;

public class MeuLookupDispachAction extends LookupDispatchAction {

	public MeuLookupDispachAction() {
		keyMethodMap = new HashMap();
		keyMethodMap.put("button.create", "create");
		keyMethodMap.put("button.find", "find");
		keyMethodMap.put("button.delete", "delete");
	}

	public ActionForward create(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return mapping.findForward("cadastrado");
	}

	public ActionForward find(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return mapping.findForward("encontrado");
	}

	public ActionForward delete(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return mapping.findForward("removido");
	}
	@Override
	protected Map getKeyMethodMap() {
		return keyMethodMap;
	}

}
