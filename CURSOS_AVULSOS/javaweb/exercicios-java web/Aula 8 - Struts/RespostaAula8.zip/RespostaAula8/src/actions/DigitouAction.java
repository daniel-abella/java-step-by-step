package actions;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;


public class DigitouAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ActionForward af = null;
		DynaActionForm dynaForm = (DynaActionForm)form;
		if(dynaForm.get("texto").equals("3")){
			af = mapping.findForward("sucesso");
		}else{
			af = mapping.findForward("erro");
		}
		return af;
	}
}
