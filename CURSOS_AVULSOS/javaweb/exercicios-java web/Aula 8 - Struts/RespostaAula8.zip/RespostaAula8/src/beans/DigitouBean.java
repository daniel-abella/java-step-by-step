package beans;

import org.apache.struts.action.ActionForm;

public class DigitouBean extends ActionForm {
	String texto;
	
	public void setTexto(String texto) {
		this.texto = texto;
	}
	
	public String getTexto() {
		return texto;
	}
}
