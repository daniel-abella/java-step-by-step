package qualiti;

import org.apache.struts.action.*;
import javax.servlet.http.*;

public class InscricaoAction extends Action {
  public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
    InscricaoActionForm form = (InscricaoActionForm)actionForm;
    String nome = form.getNome();
    int idade = form.getIdade();
    System.out.println("Nome: "+nome);
    System.out.println("Idade: "+idade);
    ActionForward af = null;
    if(idade >18) {
      af = actionMapping.findForward("ok");
    } else {
      af = actionMapping.findForward("erro");
    }
    return af;
  }
}