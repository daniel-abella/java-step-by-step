package qualiti;

import org.apache.struts.action.*;
import javax.servlet.http.*;

public class InscricaoActionForm extends ActionForm {
	private int idade;
	private String nome = "escreva seu nome";

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public int getIdade() {
		return idade;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}
}