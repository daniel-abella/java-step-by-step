package com.qualiti.bean;
public class TextoBean {
	private String texto;

	public TextoBean() {
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public String getTexto() {
		return texto;
	}
}
