package qib.util;

public class LoginBean {

  private String usuario;

  private String senha;

  public LoginBean() {
  }

  public String getUsuario() {
    return this.usuario;
  }

  public String getSenha() {
    return this.senha;
  }

  public void setUsuario(String usuario) {
    this.usuario = usuario;
  }

  public void setSenha(String senha) {
    this.senha = senha;
  }
}
