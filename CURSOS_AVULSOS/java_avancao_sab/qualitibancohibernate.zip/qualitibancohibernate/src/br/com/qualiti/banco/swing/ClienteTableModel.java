package br.com.qualiti.banco.swing;

import javax.swing.table.DefaultTableModel;

public class ClienteTableModel extends DefaultTableModel {



}
