/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget;

import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author echo
 */
public class TableCellDateRenderer extends DefaultTableCellRenderer {

    private static final long serialVersionUID = 1L;
    private SimpleDateFormat format;

    public TableCellDateRenderer(String pattern) {
        this.format = new SimpleDateFormat(pattern);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if (value != null && value instanceof Date) {
            Date date = (Date) value;

            String text = format.format(date);
            label.setText(text);
        }

        return label;
    }
}
