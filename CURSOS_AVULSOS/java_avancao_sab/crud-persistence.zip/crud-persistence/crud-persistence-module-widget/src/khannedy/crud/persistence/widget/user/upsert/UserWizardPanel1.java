/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user.upsert;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;
import javax.swing.event.ChangeListener;
import khannedy.crud.persistence.entity.User;
import org.openide.WizardDescriptor;
import org.openide.util.ChangeSupport;
import org.openide.util.HelpCtx;

public class UserWizardPanel1 implements WizardDescriptor.Panel, PropertyChangeListener {

    /**
     * The visual component that displays this panel. If you need to access the
     * component from this class, just use getComponent().
     */
    private UserVisualPanel1 component;
    private ChangeSupport changeSupport;
    private WizardDescriptor descriptor;
    private boolean valid;

    public UserWizardPanel1() {
        changeSupport = new ChangeSupport(this);
    }

    // Get the visual component for the panel. In this template, the component
    // is kept separate. This can be more efficient: if the wizard is created
    // but never displayed, or not all panels are displayed, it is better to
    // create only those which really need to be visible.
    @Override
    public Component getComponent() {
        if (component == null) {
            component = new UserVisualPanel1();
            component.addPropertyChangeListener(this);
        }
        return component;
    }

    @Override
    public HelpCtx getHelp() {
        // Show no Help button for this panel:
        return HelpCtx.DEFAULT_HELP;
        // If you have context help:
        // return new HelpCtx(SampleWizardPanel1.class);
    }

    @Override
    public boolean isValid() {
        return valid;
    }

    @Override
    public void addChangeListener(ChangeListener l) {
        changeSupport.addChangeListener(l);
    }

    @Override
    public void removeChangeListener(ChangeListener l) {
        changeSupport.removeChangeListener(l);
    }

    public void fireChange() {
        changeSupport.fireChange();
    }

    @Override
    public void readSettings(Object settings) {
        descriptor = (WizardDescriptor) settings;
        if (descriptor.getProperty("USER") != null) {
            User user = (User) descriptor.getProperty("USER");
            component.getTextBirthDay().setValue(user.getBirthDay());
            component.getTextName().setText(user.getName());

            User newuser = getNewUser(descriptor);
            newuser.setId(user.getId());
        }
    }

    @Override
    public void storeSettings(Object settings) {
        // do nothing
    }

    public User getNewUser(WizardDescriptor descriptor) {
        User user = (User) descriptor.getProperty("NEW_USER");
        if (user == null) {
            user = new User();
            descriptor.putProperty("NEW_USER", user);
        }
        return user;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName().equals("USER")) {
            if (component.getTextName().getText().trim().isEmpty()) {
                valid = false;
                descriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, "Please, fill the name field");
            } else if (component.getTextName().getText().trim().length() > 45) {
                valid = false;
                descriptor.putProperty(WizardDescriptor.PROP_WARNING_MESSAGE, "Sorry, you can not fill more than 45 char for name field");
            } else if (component.getTextBirthDay().getValue() == null) {
                valid = false;
                descriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, "Please, fill the birthday field");
            } else {

                User user = getNewUser(descriptor);
                user.setName(component.getTextName().getText());
                user.setBirthDay((Date) component.getTextBirthDay().getValue());

                valid = true;
                descriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, null);
            }
            fireChange();
        }
    }
}
