/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user;

import java.beans.PropertyEditorSupport;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author echo
 */
public class DatePropertyEditor extends PropertyEditorSupport {

    private SimpleDateFormat format;

    public DatePropertyEditor() {
        format = new SimpleDateFormat("d MMMM yyyy");
    }

    @Override
    public String getAsText() {
        Date date = (Date) getValue();
        return format.format(date);
    }
}
