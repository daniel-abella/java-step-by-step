package khannedy.crud.persistence.widget.group;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.service.ServiceFactory;
import khannedy.crud.persistence.widget.group.upsert.GroupWizardAction;
import org.netbeans.api.progress.ProgressHandle;
import org.netbeans.api.progress.ProgressHandleFactory;
import org.openide.DialogDisplayer;
import org.openide.NotifyDescriptor;
import org.openide.util.Lookup;
import org.openide.util.NbBundle;

public class GroupController {

    private GroupTopComponent component;
    private Executor executor;

    public GroupController(GroupTopComponent component) {
        this.component = component;
        executor = Executors.newCachedThreadPool();
    }

    public void reload() {
        executor.execute(new Runnable() {

            @Override
            public void run() {
                ProgressHandle handle = ProgressHandleFactory.createHandle(NbBundle.getMessage(GroupController.class, "LOADING_GROUPS"));
                handle.start();

                ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);
                List<Group> groups = factory.getGroup().getAll();

                component.getTableModelGroup().reload(groups);

                handle.finish();
            }
        });
    }

    public void create() {
        ProgressHandle handle = ProgressHandleFactory.createHandle(NbBundle.getMessage(GroupController.class, "CREATE_NEW_GROUP"));
        handle.start();

        GroupWizardAction action = new GroupWizardAction();
        Group group = action.performCreate();

        if (group != null) {
            ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);
            factory.getGroup().save(group);

            component.getTableModelGroup().add(group);
        }

        handle.finish();
    }

    public void edit() {
        ProgressHandle handle = ProgressHandleFactory.createHandle(NbBundle.getMessage(GroupController.class, "EDIT_SELECTED_GROUP"));
        handle.start();

        int index = component.getTableGroup().getSelectedRow();
        if (index == -1) {
            // nothing to update
        } else {
            GroupWizardAction action = new GroupWizardAction();
            Group group = action.performEdit(component.getTableModelGroup().get(index));

            if (group != null) {
                ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);
                factory.getGroup().update(group);

                component.getTableModelGroup().update(index, group);
            }
        }

        handle.finish();
    }

    public void remove() {
        ProgressHandle handle = ProgressHandleFactory.createHandle(NbBundle.getMessage(GroupController.class, "REMOVE_SELECTED_GROUP"));
        handle.start();

        int index = component.getTableGroup().getSelectedRow();
        if (index == -1) {
            // do nothing
        } else {
            NotifyDescriptor.Confirmation c = new NotifyDescriptor.Confirmation(new String[]{
                        "Are you sure", "want to delete?"
                    }, "Delete a group", NotifyDescriptor.OK_CANCEL_OPTION);
            if (DialogDisplayer.getDefault().notify(c) == NotifyDescriptor.OK_OPTION) {

                ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);
                Group group = component.getTableModelGroup().get(index);
                boolean success = factory.getGroup().delete(group);

                if (success) {
                    component.getTableModelGroup().remove(index);
                } else {
                    // do nothing
                }
            }
        }

        handle.finish();
    }

    public void search() {
        executor.execute(new Runnable() {

            @Override
            public void run() {
                ProgressHandle handle = ProgressHandleFactory.createHandle("Searching group...");
                handle.start();

                String query = component.getTextSearch().getText();
                ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);

                List<Group> groups = factory.getGroup().searchByName(query);
                component.getTableModelGroup().reload(groups);

                if (groups.isEmpty()) {
                    NotifyDescriptor descriptor = new NotifyDescriptor.Message("Group is not found");
                    DialogDisplayer.getDefault().notify(descriptor);
                }

                handle.finish();
            }
        });
    }
}
