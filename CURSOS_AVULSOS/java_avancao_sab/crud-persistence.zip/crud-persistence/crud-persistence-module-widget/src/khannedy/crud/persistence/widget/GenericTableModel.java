package khannedy.crud.persistence.widget;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public abstract class GenericTableModel<T> extends AbstractTableModel {

    private static final long serialVersionUID = 1L;
    private List<T> data;

    public GenericTableModel() {
        data = new ArrayList<T>(0);
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    public void add(T object) {
        data.add(object);
        fireTableRowsInserted(getRowCount() - 1, getRowCount() - 1);
    }

    public void remove(int index) {
        data.remove(index);
        fireTableRowsDeleted(index, index);
    }

    public void update(int index, T object) {
        data.set(index, object);
        fireTableRowsUpdated(index, index);
    }

    public T get(int index) {
        return data.get(index);
    }

    public void reload(Collection<? extends T> collection) {
        data.clear();
        data.addAll(collection);
        fireTableDataChanged();
    }
}
