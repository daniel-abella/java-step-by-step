/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import khannedy.crud.persistence.entity.User;
import khannedy.crud.persistence.service.ServiceFactory;
import khannedy.crud.persistence.service.UserService;
import khannedy.crud.persistence.widget.user.upsert.UserWizardAction;
import org.netbeans.api.progress.ProgressHandle;
import org.netbeans.api.progress.ProgressHandleFactory;
import org.openide.DialogDisplayer;
import org.openide.NotifyDescriptor;
import org.openide.NotifyDescriptor.Confirmation;
import org.openide.util.Lookup;

/**
 *
 * @author echo
 */
public class UserController {

    private Executor executor;
    private UserTopComponent component;
    private UserService service;

    public UserController(UserTopComponent component) {
        this.component = component;
        executor = Executors.newCachedThreadPool();
        service = Lookup.getDefault().lookup(ServiceFactory.class).getUser();
    }

    public void reload() {
        executor.execute(new Runnable() {

            @Override
            public void run() {
                ProgressHandle handle = ProgressHandleFactory.createHandle("Loading users");
                handle.start();

                List<User> users = service.getAll();
                component.getTableModelUser().reload(users);

                handle.finish();
            }
        });
    }

    public void create() {
        ProgressHandle handle = ProgressHandleFactory.createHandle("Create new user");
        handle.start();

        User user = new UserWizardAction().performCreate();
        if (user != null) {
            service.save(user);

            component.getTableModelUser().add(user);
        }

        handle.finish();
    }

    public void edit() {
        ProgressHandle handle = ProgressHandleFactory.createHandle("Edit selected user");
        handle.start();

        int index = component.getTableUser().getSelectedRow();
        if (index == -1) {
            // do nothing
        } else {
            User user = new UserWizardAction().performEdit(component.getTableModelUser().get(index));
            if (user != null) {
                service.update(user);
                component.getTableModelUser().update(index, user);
            }
        }

        handle.finish();
    }

    public void delete() {
        ProgressHandle handle = ProgressHandleFactory.createHandle("Delete selected user");
        handle.start();

        int index = component.getTableUser().getSelectedRow();
        if (index == -1) {
            // do nothing
        } else {
            Confirmation confirmation = new Confirmation(new String[]{
                        "Are you sure", "want to delete?"
                    }, "Delete selected user", NotifyDescriptor.OK_CANCEL_OPTION);
            if (NotifyDescriptor.OK_OPTION == DialogDisplayer.getDefault().notify(confirmation)) {
                User user = component.getTableModelUser().get(index);
                service.delete(user);
                component.getTableModelUser().remove(index);
            }
        }

        handle.finish();
    }

    public void search() {
        executor.execute(new Runnable() {

            @Override
            public void run() {
                ProgressHandle handle = ProgressHandleFactory.createHandle("Searching user...");
                handle.start();

                String query = component.getTextSearch();
                List<User> users = service.searchByName(query);

                component.getTableModelUser().reload(users);

                if (users.isEmpty()) {
                    NotifyDescriptor.Message message = new NotifyDescriptor.Message("User is not found");
                    DialogDisplayer.getDefault().notify(message);
                }

                handle.finish();
            }
        });
    }
}
