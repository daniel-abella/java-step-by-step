/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user;

import java.util.Date;
import khannedy.crud.persistence.entity.User;
import org.openide.nodes.AbstractNode;
import org.openide.nodes.Children;
import org.openide.nodes.PropertySupport;
import org.openide.nodes.PropertySupport.Reflection;
import org.openide.nodes.Sheet;
import org.openide.util.Exceptions;

/**
 *
 * @author echo
 */
public class UserNode extends AbstractNode {

    private User user;

    public UserNode() {
        this(null);
    }

    public UserNode(User user) {
        super(Children.LEAF);
        this.user = user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    protected Sheet createSheet() {
        Sheet sheet = super.createSheet();

        Sheet.Set setUser = Sheet.createPropertiesSet();
        setUser.setName("User");
        setUser.setDisplayName("User");

        try {
            Property<Long> propertyId = new Reflection<Long>(user, Long.class, "getId", null);
            propertyId.setName("Id");
            propertyId.setShortDescription("The identifier of user");
            setUser.put(propertyId);

            Property<String> propertyName = new Reflection<String>(user, String.class, "getName", null);
            propertyName.setName("Name");
            propertyName.setShortDescription("The name of user");
            setUser.put(propertyName);

            PropertySupport.Reflection<Date> propertyBirthDay = new Reflection<Date>(user, Date.class, "getBirthDay", null);
            propertyBirthDay.setName("Birth Day");
            propertyBirthDay.setShortDescription("The birth day of user");
            propertyBirthDay.setPropertyEditorClass(DatePropertyEditor.class);

            setUser.put(propertyBirthDay);
        } catch (NoSuchMethodException ex) {
            Exceptions.printStackTrace(ex);
        }

        Sheet.Set setGroup = Sheet.createPropertiesSet();
        setGroup.setName("Group");
        setGroup.setDisplayName("Group");

        try {
            Property<Long> propertyId = new Reflection<Long>(user.getGroup(), Long.class, "getId", null);
            propertyId.setName("Id");
            propertyId.setShortDescription("The identifier of group");
            setGroup.put(propertyId);

            Property<String> propertyName = new Reflection<String>(user.getGroup(), String.class, "getName", null);
            propertyName.setName("Name");
            propertyName.setShortDescription("The name of group");
            setGroup.put(propertyName);
        } catch (NoSuchMethodException ex) {
            Exceptions.printStackTrace(ex);
        }

        sheet.put(setUser);
        sheet.put(setGroup);

        return sheet;
    }
}
