package khannedy.crud.persistence.widget.group;

import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.widget.GenericTableModel;

public class GroupTableModel extends GenericTableModel<Group> {

    private static final long serialVersionUID = 1L;

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return get(rowIndex).getId();
            case 1:
                return get(rowIndex).getName();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id";
            case 1:
                return "Name";
            default:
                return null;
        }
    }

    @Override
    public int getColumnCount() {
        return 2;
    }
}
