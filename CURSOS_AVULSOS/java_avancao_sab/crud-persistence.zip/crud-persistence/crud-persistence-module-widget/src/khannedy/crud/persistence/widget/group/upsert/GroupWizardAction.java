package khannedy.crud.persistence.widget.group.upsert;

import java.awt.Component;
import java.awt.Dialog;
import java.text.MessageFormat;
import javax.swing.JComponent;
import khannedy.crud.persistence.entity.Group;
import org.openide.DialogDisplayer;
import org.openide.WizardDescriptor;

public class GroupWizardAction {

    private WizardDescriptor.Panel<WizardDescriptor>[] panels;

    public GroupWizardAction() {
    }

    public Group performCreate() {
        return performEdit(null);
    }

    public Group performEdit(Group group) {
        WizardDescriptor wizardDescriptor = new WizardDescriptor(getPanels());
        wizardDescriptor.setTitleFormat(new MessageFormat("{0}"));

        if (group == null) {
            wizardDescriptor.setTitle("Create new group");
        } else {
            wizardDescriptor.setTitle("Edit group");
            wizardDescriptor.putProperty("GROUP", group);
        }

        Dialog dialog = DialogDisplayer.getDefault().createDialog(wizardDescriptor);
        dialog.setVisible(true);
        dialog.toFront();

        boolean finish = wizardDescriptor.getValue() == WizardDescriptor.FINISH_OPTION;

        if (finish) {
            Group newgroup = (Group) wizardDescriptor.getProperty("NEW_GROUP");
            return newgroup;
        } else {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "ReturnOfCollectionOrArrayField"})
    private WizardDescriptor.Panel<WizardDescriptor>[] getPanels() {
        if (panels == null) {
            panels = new WizardDescriptor.Panel[]{
                        new GroupWizardPanel()
                    };
            String[] steps = new String[panels.length];
            for (int i = 0; i < panels.length; i++) {
                Component c = panels[i].getComponent();
                // Default step name to component name of panel. Mainly useful
                // for getting the name of the target chooser to appear in the
                // list of steps.
                steps[i] = c.getName();
                if (c instanceof JComponent) { // assume Swing components
                    JComponent jc = (JComponent) c;
                    // Sets step number of a component
                    // TODO if using org.openide.dialogs >= 7.8, can use WizardDescriptor.PROP_*:
                    jc.putClientProperty("WizardPanel_contentSelectedIndex", new Integer(i));
                    // Sets steps names for a panel
                    jc.putClientProperty("WizardPanel_contentData", steps);
                    // Turn on subtitle creation on each step
                    jc.putClientProperty("WizardPanel_autoWizardStyle", Boolean.TRUE);
                    // Show steps on the left side with the image on the background
                    jc.putClientProperty("WizardPanel_contentDisplayed", Boolean.TRUE);
                    // Turn on numbering of all steps
                    jc.putClientProperty("WizardPanel_contentNumbered", Boolean.TRUE);
                }
            }
        }
        return panels;
    }
}
