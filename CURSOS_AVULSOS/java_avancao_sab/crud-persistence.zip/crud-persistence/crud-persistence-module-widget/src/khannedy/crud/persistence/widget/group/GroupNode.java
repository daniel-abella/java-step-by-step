package khannedy.crud.persistence.widget.group;

import khannedy.crud.persistence.entity.Group;
import org.openide.nodes.AbstractNode;
import org.openide.nodes.Children;
import org.openide.nodes.PropertySupport;
import org.openide.nodes.Sheet;
import org.openide.util.Exceptions;

public class GroupNode extends AbstractNode {

    private final Group group;

    public GroupNode(Group group) {
        super(Children.LEAF);
        this.group = group;
    }

    @Override
    protected Sheet createSheet() {
        Sheet sheet = new Sheet();
        Sheet.Set set = Sheet.createPropertiesSet();
        set.setDisplayName("Group");

        try {
            Property<Long> id = new PropertySupport.Reflection<Long>(group, Long.class, "getId", null);
            id.setName("Id");
            id.setShortDescription("The identifier of group");
            set.put(id);

            Property<String> name = new PropertySupport.Reflection<String>(group, String.class, "getName", null);
            name.setName("Name");
            name.setShortDescription("The name of group");
            set.put(name);
        } catch (NoSuchMethodException ex) {
            Exceptions.printStackTrace(ex);
        }

        sheet.put(set);
        return sheet;
    }
}
