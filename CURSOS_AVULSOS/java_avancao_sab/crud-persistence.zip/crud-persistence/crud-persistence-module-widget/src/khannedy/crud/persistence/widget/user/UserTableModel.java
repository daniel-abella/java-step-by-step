/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user;

import khannedy.crud.persistence.entity.User;
import khannedy.crud.persistence.widget.GenericTableModel;

/**
 *
 * @author echo
 */
public class UserTableModel extends GenericTableModel<User> {

    private static final long serialVersionUID = 1L;

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return get(rowIndex).getId();
            case 1:
                return get(rowIndex).getName();
            case 2:
                return get(rowIndex).getBirthDay();
            case 3:
                return get(rowIndex).getGroup().getName();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id";
            case 1:
                return "Name";
            case 2:
                return "Birth Day";
            case 3:
                return "Group";
            default:
                return null;
        }
    }
}
