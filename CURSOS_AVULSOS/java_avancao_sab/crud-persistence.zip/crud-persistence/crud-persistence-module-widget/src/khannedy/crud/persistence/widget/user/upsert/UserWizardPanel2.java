/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.widget.user.upsert;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.event.ChangeListener;
import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.entity.User;
import khannedy.crud.persistence.service.ServiceFactory;
import org.openide.WizardDescriptor;
import org.openide.util.ChangeSupport;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;

public class UserWizardPanel2 implements WizardDescriptor.Panel, PropertyChangeListener {

    /**
     * The visual component that displays this panel. If you need to access the
     * component from this class, just use getComponent().
     */
    private UserVisualPanel2 component;
    private WizardDescriptor descriptor;
    private boolean valid;

    // Get the visual component for the panel. In this template, the component
    // is kept separate. This can be more efficient: if the wizard is created
    // but never displayed, or not all panels are displayed, it is better to
    // create only those which really need to be visible.
    @Override
    public Component getComponent() {
        if (component == null) {
            component = new UserVisualPanel2();
            component.addPropertyChangeListener(this);
        }
        return component;
    }

    @Override
    public HelpCtx getHelp() {
        // Show no Help button for this panel:
        return HelpCtx.DEFAULT_HELP;
        // If you have context help:
        // return new HelpCtx(SampleWizardPanel1.class);
    }

    @Override
    public boolean isValid() {
        return valid;
    }
    private ChangeSupport changeSupport = new ChangeSupport(this);

    @Override
    public void addChangeListener(ChangeListener l) {
        changeSupport.addChangeListener(l);
    }

    @Override
    public void removeChangeListener(ChangeListener l) {
        changeSupport.removeChangeListener(l);
    }

    public void fireChange() {
        changeSupport.fireChange();
    }

    @Override
    public void readSettings(Object settings) {

        descriptor = (WizardDescriptor) settings;

        component.getComboGroup().removeAllItems();

        ServiceFactory factory = Lookup.getDefault().lookup(ServiceFactory.class);
        List<Group> groups = factory.getGroup().getAll();
        for (Group group : groups) {
            component.getComboGroup().addItem(group);
        }

        if (descriptor.getProperty("USER") != null) {
            User user = (User) descriptor.getProperty("USER");

            component.getComboGroup().setSelectedItem(user.getGroup());

            User newuser = getNewUser(descriptor);
            newuser.setId(user.getId());
        }
    }

    @Override
    public void storeSettings(Object settings) {
        // do nothing
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName().equals("USER")) {
            if (component.getComboGroup().getSelectedIndex() == -1) {
                valid = false;
                descriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, "Please, select a group");
            } else {

                User user = getNewUser(descriptor);
                user.setGroup((Group) component.getComboGroup().getSelectedItem());

                valid = true;
                descriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, null);
            }
            fireChange();
        }
    }

    private User getNewUser(WizardDescriptor descriptor) {
        User user = (User) descriptor.getProperty("NEW_USER");
        if (user == null) {
            user = new User();
            descriptor.putProperty("NEW_USER", user);
        }
        return user;
    }
}
