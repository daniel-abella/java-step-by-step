package khannedy.crud.persistence.widget.group.upsert;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.event.ChangeListener;
import khannedy.crud.persistence.entity.Group;
import org.openide.WizardDescriptor;
import org.openide.util.ChangeSupport;
import org.openide.util.HelpCtx;

public class GroupWizardPanel implements
        WizardDescriptor.Panel<WizardDescriptor>, PropertyChangeListener {

    private GroupVisualPanel component;
    private ChangeSupport changeSupport;
    private boolean valid;
    private WizardDescriptor settings;

    public GroupWizardPanel() {
        changeSupport = new ChangeSupport(this);
    }

    @Override
    public Component getComponent() {
        if (component == null) {
            component = new GroupVisualPanel();
            component.addPropertyChangeListener(this);
        }
        return component;
    }

    @Override
    public HelpCtx getHelp() {
        return new HelpCtx("khannedy.crud.persistence.help.about");
    }

    @Override
    public boolean isValid() {
        return valid;
    }

    @Override
    public void addChangeListener(ChangeListener l) {
        changeSupport.addChangeListener(l);
    }

    @Override
    public void removeChangeListener(ChangeListener l) {
        changeSupport.addChangeListener(l);
    }

    public void fireChange() {
        changeSupport.fireChange();
    }

    @Override
    public void readSettings(WizardDescriptor settings) {
        this.settings = settings;
        if (settings.getProperty("GROUP") != null) {
            Group group = (Group) settings.getProperty("GROUP");
            component.getTextName().setText(group.getName());

            Group newgroup = getNewGroup(settings);
            newgroup.setId(group.getId());
        }
    }

    @Override
    public void storeSettings(WizardDescriptor settings) {
        // do nothing
    }

    public Group getNewGroup(WizardDescriptor settings) {
        Group group = (Group) settings.getProperty("NEW_GROUP");
        if (group == null) {
            group = new Group();
        }
        return group;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName().equals(GroupVisualPanel.PROP_USER)) {
            if (component.getTextName().getText().trim().isEmpty()) {
                valid = false;
                settings.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, "Please fill the name field");
            } else if (component.getTextName().getText().trim().length() > 45) {
                valid = false;
                settings.putProperty(WizardDescriptor.PROP_WARNING_MESSAGE, "Sorry, you can not fill more than 45 char for name field");
            } else {

                Group group = getNewGroup(settings);

                group.setName(component.getTextName().getText());
                settings.putProperty("NEW_GROUP", group);

                valid = true;
                settings.putProperty(WizardDescriptor.PROP_ERROR_MESSAGE, null);
                settings.putProperty(WizardDescriptor.PROP_WARNING_MESSAGE, null);
                settings.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, null);
            }
            fireChange();
        }
    }
}
