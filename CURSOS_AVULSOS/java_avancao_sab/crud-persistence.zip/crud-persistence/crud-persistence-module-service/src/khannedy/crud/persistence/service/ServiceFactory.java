package khannedy.crud.persistence.service;

public interface ServiceFactory {

    UserService getUser();

    GroupService getGroup();
}
