/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.service;

import java.util.List;
import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.entity.User;

/**
 *
 * @author echo
 */
public interface UserService extends DefaultService<User, Long> {

    List<User> getAllByGroup(Group group);

    List<User> searchByName(String name);
}
