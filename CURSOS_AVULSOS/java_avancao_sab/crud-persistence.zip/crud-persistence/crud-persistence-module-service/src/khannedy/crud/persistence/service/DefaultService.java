/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package khannedy.crud.persistence.service;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author echo
 */
public interface DefaultService<T, ID extends Serializable> {

    void save(T entity);

    void update(T entity);

    boolean delete(T entity);

    T get(ID id);

    List<T> getAll();
}
