package khannedy.crud.persistence.service.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.service.GroupService;

public class GroupServiceJpa implements GroupService {

    private EntityManagerFactory factory;

    public GroupServiceJpa(EntityManagerFactory factory) {
        this.factory = factory;
    }

    @Override
    public void save(Group entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            manager.persist(entity);

            manager.getTransaction().commit();
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public void update(Group entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            manager.<Group>merge(entity);

            manager.getTransaction().commit();
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public boolean delete(Group entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            Group group = manager.find(Group.class, entity.getId());
            if (group.getUsers().size() > 0) {
                return false;
            }

            manager.remove(manager.<Group>merge(entity));

            manager.getTransaction().commit();
            return true;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public Group get(Long id) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            Group group = manager.find(Group.class, id);

            manager.getTransaction().commit();
            return group;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public List<Group> getAll() {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<Group> query = builder.createQuery(Group.class);
            Root<Group> group = query.from(Group.class);

            query.select(group);

            List<Group> groups = manager.createQuery(query).getResultList();

            manager.getTransaction().commit();
            return groups;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public List<Group> searchByName(String name) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<Group> query = builder.createQuery(Group.class);
            Root<Group> group = query.from(Group.class);

            query.select(group).where(builder.like(group.<String>get("name"), name));

            List<Group> groups = manager.createQuery(query).getResultList();

            manager.getTransaction().commit();
            return groups;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }
}
