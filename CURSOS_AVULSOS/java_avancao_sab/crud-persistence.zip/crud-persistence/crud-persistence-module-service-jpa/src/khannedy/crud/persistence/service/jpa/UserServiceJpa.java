package khannedy.crud.persistence.service.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import khannedy.crud.persistence.entity.Group;
import khannedy.crud.persistence.entity.User;
import khannedy.crud.persistence.service.UserService;

public class UserServiceJpa implements UserService {

    private EntityManagerFactory factory;

    public UserServiceJpa(EntityManagerFactory factory) {
        this.factory = factory;
    }

    @Override
    public List<User> getAllByGroup(Group group) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<User> query = builder.createQuery(User.class);
            Root<User> user = query.from(User.class);

            query.select(user).where(builder.equal(user.get("group"), group));
            List<User> users = manager.createQuery(query).getResultList();

            manager.getTransaction().commit();
            return users;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public void save(User entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();
            manager.persist(entity);
            manager.getTransaction().commit();
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public void update(User entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();
            manager.<User>merge(entity);
            manager.getTransaction().commit();
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public boolean delete(User entity) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();
            manager.remove(manager.<User>merge(entity));
            manager.getTransaction().commit();
            return true;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public User get(Long id) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();
            User user = manager.find(User.class, id);
            manager.getTransaction().commit();
            return user;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public List<User> getAll() {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<User> query = builder.createQuery(User.class);
            Root<User> user = query.from(User.class);

            query.select(user);

            List<User> users = manager.createQuery(query).getResultList();

            manager.getTransaction().commit();
            return users;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }

    @Override
    public List<User> searchByName(String name) {
        EntityManager manager = factory.createEntityManager();
        try {
            manager.getTransaction().begin();

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<User> query = builder.createQuery(User.class);
            Root<User> user = query.from(User.class);

            query.select(user).where(builder.like(user.<String>get("name"), name));

            List<User> users = manager.createQuery(query).getResultList();

            manager.getTransaction().commit();
            return users;
        } catch (PersistenceException pe) {
            manager.getTransaction().rollback();
            throw pe;
        } finally {
            manager.close();
        }
    }
}
