package khannedy.crud.persistence.service.jpa;

import khannedy.crud.persistence.service.ServiceFactory;
import org.openide.LifecycleManager;
import org.openide.modules.ModuleInstall;
import org.openide.util.Lookup;

public class Installer extends ModuleInstall {

    private static final long serialVersionUID = 1L;

    @Override
    public void restored() {
        // By default, do nothing.
        // Put your startup code here.
        PersistenceUtilities.getManagerFactory();
    }

    @Override
    public void close() {
        super.close();
        PersistenceUtilities.getManagerFactory().close();
    }
}
