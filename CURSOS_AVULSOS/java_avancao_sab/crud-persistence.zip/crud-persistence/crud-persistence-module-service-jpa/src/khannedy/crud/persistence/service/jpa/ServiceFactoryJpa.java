package khannedy.crud.persistence.service.jpa;

import javax.persistence.EntityManagerFactory;
import khannedy.crud.persistence.service.GroupService;
import khannedy.crud.persistence.service.ServiceFactory;
import khannedy.crud.persistence.service.UserService;

public class ServiceFactoryJpa implements ServiceFactory {

    private EntityManagerFactory factory;
    private UserService user;
    private GroupService group;

    public ServiceFactoryJpa() {
        factory = PersistenceUtilities.getManagerFactory();
    }

    @Override
    public UserService getUser() {
        if (user == null) {
            user = new UserServiceJpa(factory);
        }
        return user;
    }

    @Override
    public GroupService getGroup() {
        if (group == null) {
            group = new GroupServiceJpa(factory);
        }
        return group;
    }
}
