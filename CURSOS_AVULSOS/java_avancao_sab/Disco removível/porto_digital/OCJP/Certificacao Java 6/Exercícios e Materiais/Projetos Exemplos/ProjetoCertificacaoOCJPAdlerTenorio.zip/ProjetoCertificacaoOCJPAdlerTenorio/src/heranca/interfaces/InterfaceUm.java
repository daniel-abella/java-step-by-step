package heranca.interfaces;
public interface InterfaceUm extends InterfaceDois, InterfaceTres {

    boolean existe();
}
