package heranca.interfaces3;

public class Sente implements IGo{

	@Override
	public void go() {
		System.out.println("go in Sente.");
	}
}
