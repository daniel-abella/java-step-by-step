package heranca.cast;

public class ClasseA {
	
	public void start() {
		System.out.println("A");
	}
	
}
