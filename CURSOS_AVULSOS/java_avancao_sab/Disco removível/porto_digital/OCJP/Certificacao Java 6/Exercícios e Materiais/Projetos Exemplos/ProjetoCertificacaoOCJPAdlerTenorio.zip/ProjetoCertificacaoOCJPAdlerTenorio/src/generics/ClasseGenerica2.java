package generics;

public class ClasseGenerica2<T extends Animal> {

}
