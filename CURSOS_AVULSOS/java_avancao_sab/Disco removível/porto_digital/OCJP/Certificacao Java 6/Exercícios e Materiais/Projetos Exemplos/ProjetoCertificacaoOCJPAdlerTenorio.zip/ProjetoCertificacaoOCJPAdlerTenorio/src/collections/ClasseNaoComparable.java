package collections;

public class ClasseNaoComparable {

}
