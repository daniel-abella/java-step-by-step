package heranca.interfaces;
public abstract class AbstractClasseTeste {

    public abstract boolean existeChaves();
}
