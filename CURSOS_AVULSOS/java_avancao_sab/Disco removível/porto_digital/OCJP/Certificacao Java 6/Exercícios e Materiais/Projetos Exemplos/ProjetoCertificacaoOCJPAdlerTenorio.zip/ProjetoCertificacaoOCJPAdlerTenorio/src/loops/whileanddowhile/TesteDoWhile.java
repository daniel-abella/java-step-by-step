package loops.whileanddowhile;

public class TesteDoWhile {

    public static void main(String[] args) {

        int x = 1;
        do {
            x++;
            System.out.println("Imprime " + x);
        } while (x < 10);
    }
}
