package heranca.interfaces;
public interface InterfaceTres {

    boolean somar();
}
