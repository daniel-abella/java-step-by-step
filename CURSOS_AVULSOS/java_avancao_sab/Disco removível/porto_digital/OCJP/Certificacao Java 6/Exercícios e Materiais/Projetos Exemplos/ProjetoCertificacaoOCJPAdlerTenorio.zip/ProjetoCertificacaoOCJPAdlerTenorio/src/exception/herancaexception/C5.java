package exception.herancaexception;

public class C5 extends C {

    @Override
    public void doStuff() {
    }
}
