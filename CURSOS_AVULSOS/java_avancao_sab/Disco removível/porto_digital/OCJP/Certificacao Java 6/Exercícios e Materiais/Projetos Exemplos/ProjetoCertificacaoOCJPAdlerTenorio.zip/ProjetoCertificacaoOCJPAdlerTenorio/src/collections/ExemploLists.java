package collections;

public class ExemploLists {
	
	public static void main(String[] args) {
		
		 /** In�cio exempplo 01 .*/
		Pessoa ana = new Pessoa("Ana", 99);
		Pessoa bia = new Pessoa("Bia", 02);
		Pessoa caio = new Pessoa("Caio", 03);
		Pessoa zito = new Pessoa("Zito", 04);
		Pessoa coringa = new Pessoa("X", 05);

//
//		ArrayList<Pessoa> listaNaoClassificada = new ArrayList<Pessoa>();
//		listaNaoClassificada.add(zito);
//		listaNaoClassificada.add(bia);
//		listaNaoClassificada.add(caio);
//		listaNaoClassificada.add(ana);
//		listaNaoClassificada.add(1, coringa);
//
//		Collections.sort(listaNaoClassificada);
//		for (Pessoa nome : listaNaoClassificada) {
//			System.out.println(nome.getNome());
//		}
		 /** Fim exempplo 01 .*/
		
		
		 /** In�cio exempplo 02 .*/
//		 TreeSet<Pessoa> listaClassificada = new TreeSet<Pessoa>();
//		 listaClassificada.add(bia);
//		 listaClassificada.add(ana);
//		 listaClassificada.add(coringa);
//		 listaClassificada.add(zito);
//		 listaClassificada.add(caio); // S� insere uma vez.
//		 listaClassificada.add(caio);
//		 listaClassificada.add(caio);
//		 listaClassificada.add(caio);
//		
//		 for (Pessoa nome : listaClassificada) {
//		 System.out.println(nome.getNome());
//		 }
		 /** Fim exempplo 02 .*/
	}

}
