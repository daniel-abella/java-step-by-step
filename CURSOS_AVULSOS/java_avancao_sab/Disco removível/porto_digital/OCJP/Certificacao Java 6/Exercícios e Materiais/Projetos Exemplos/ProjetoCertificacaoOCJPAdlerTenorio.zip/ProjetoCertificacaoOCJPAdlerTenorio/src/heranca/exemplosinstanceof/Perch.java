package heranca.exemplosinstanceof;

public class Perch implements Fish {

}
