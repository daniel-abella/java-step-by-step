package enums;

public class DeclaracaoEnumsEmClasse {

	public static enum Colors1 {
		RED, GREEN, BLUE
	};

	protected enum Colors2 {
		RED, GREEN, BLUE
	};

	private enum Colors3 {
		RED, GREEN, BLUE
	};

	static enum Colors4 {
		RED, GREEN, BLUE
	};

	public enum Colors5 {
		RED, GREEN, BLUE
	};

	enum Colors6 {
		RED, GREEN, BLUE
	};
}
