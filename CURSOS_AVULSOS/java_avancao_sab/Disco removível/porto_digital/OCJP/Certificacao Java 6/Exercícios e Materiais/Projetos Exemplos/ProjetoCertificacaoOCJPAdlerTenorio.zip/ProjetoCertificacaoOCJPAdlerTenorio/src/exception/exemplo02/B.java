package exception.exemplo02;

public class B {

	public void method2() throws TestException {
		throw new TestException();
	}

//	public void method() {
//		A a = new A();
//		a.method1();
//	}
}
