package heranca.cast;

public class ClasseC extends ClasseA{

}
