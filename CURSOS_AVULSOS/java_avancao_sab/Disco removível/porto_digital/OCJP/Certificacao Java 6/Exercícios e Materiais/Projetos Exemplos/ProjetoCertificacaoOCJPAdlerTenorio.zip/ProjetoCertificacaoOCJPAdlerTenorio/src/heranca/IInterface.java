package heranca;

public interface IInterface {

	void x();
	
}
