package exception.herancaexception;

public class SubSubException extends SubException {

    private static final long serialVersionUID = 1L;

}
