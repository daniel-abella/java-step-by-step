package heranca.interfaces3;

public class Stone extends Goban implements IGo {

}
