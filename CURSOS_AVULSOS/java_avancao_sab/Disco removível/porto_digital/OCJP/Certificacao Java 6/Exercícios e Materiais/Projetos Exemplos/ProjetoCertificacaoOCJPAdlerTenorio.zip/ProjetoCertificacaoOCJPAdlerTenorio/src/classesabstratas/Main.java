package classesabstratas;

public class Main {

	public static void main(String[] args) {

		
		GestaoPage paginaGestao = new GestaoPage("000001", "Pagina de Gest�o");
		System.out.println("###################################################");
		InclusaoPage paginaInclusao = new InclusaoPage("77777", "Pagina de Inclus�o");
	}
}
