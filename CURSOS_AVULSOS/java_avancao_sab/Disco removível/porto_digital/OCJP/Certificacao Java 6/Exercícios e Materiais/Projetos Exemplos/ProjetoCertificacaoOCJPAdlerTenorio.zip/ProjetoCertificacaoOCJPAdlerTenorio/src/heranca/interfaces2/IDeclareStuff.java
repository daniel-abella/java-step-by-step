package heranca.interfaces2;

public interface IDeclareStuff {

	public static final int EASY = 3; // Toda vari�vel de interface � public, static e final
	void doStuff(int t);
}
