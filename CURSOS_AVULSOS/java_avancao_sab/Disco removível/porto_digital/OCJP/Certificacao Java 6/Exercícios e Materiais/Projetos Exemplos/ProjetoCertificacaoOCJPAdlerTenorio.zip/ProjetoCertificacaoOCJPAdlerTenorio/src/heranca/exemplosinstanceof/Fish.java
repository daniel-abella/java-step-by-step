package heranca.exemplosinstanceof;

public interface Fish {

}
