package heranca;

import java.util.ArrayList;
import java.util.HashSet;

public class FilhoHashSet extends HashSet<String>{
	
	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		lista.add(1);
		
	}
}
