package generics;

public class Cat extends Animal {

    public void miar() {
        System.out.println("Miauuuuuuuuuuuuu !");
    }

}
