package generics;

import java.io.Serializable;

public class Minhoca extends Animal implements IZoologico, IInvertebrado, Serializable {

}
