package exception.herancaexception;

public class C3 extends C {

    // TODO N�o posso aumentar o n�vel de heran�a !
    @Override
    public void doStuff() throws Exception {
    }
}
