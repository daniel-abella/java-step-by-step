package generics;

public interface IInvertebrado {

}
