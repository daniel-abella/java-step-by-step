package heranca.exemplosinstanceof;

public class Walleye extends Perch{

}
