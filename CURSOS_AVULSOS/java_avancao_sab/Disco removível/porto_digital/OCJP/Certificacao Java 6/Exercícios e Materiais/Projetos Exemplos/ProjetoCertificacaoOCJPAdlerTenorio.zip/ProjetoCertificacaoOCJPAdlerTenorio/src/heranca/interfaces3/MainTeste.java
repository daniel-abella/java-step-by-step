package heranca.interfaces3;



public class MainTeste {

	public static void main(String[] args) {
		 Sente s = new Sente(); s.go(); 
		 Goban g = new Goban(); g.go(); 
		 Stone c = new Stone(); c.go(); 
	}
	
}	
