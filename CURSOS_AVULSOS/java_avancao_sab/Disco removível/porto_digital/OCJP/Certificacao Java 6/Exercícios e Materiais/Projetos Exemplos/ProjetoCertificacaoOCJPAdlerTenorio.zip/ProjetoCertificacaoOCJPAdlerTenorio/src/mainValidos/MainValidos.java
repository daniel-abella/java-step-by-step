package mainValidos;

public class MainValidos {

	/** Exemplo 01 */
	// public static void main(String[] args) {
	// }

	/** Exemplo 02 */
	// public static void main(String... args) {
	// }

	/** Exemplo 03 */
	// public static void main(String args[]) {
	//
	// System.out.println("aaaaa");
	// }

	/** Exemplo 04 */
//	 public static void main(String[]... args) {
//	
//	 System.out.println("aaaaa");
//	 }
	 
	/** N�o � v�lido */
	// public static void main(String... args[]) {
	//
	// System.out.println("aaaaa");
	// }
	
	 static public void main(String[] args) {
		
	}
}
