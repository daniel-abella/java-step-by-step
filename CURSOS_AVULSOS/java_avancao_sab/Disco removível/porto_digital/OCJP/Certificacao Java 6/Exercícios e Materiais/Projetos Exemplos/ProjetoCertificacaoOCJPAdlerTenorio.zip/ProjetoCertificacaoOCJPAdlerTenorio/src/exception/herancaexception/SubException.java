package exception.herancaexception;

public class SubException extends Exception {

    private static final long serialVersionUID = 1L;

}
