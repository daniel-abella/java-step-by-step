package exception.herancaexception;

public class C {

    public void doStuff() throws SubException {
    }
}
