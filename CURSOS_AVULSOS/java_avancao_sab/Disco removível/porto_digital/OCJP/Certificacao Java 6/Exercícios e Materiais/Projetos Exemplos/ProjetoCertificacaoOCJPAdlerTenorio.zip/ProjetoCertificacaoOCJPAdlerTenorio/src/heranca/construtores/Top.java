package heranca.construtores;

public class Top {
	
	//public Top() {}

	
	public Top(String s) {
		System.out.println("B");
	}

}
