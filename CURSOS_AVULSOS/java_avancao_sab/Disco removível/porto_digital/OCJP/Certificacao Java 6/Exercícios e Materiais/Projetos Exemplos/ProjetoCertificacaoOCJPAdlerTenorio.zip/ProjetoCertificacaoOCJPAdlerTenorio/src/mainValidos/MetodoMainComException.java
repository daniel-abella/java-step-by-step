package mainValidos;

public class MetodoMainComException {

    // 1. Compila
    // public static void main(String... args) {

    // 2. Compila
    // public static void main(String... args) throws Exception {

    // 3. Compila
    // public static void main(String... args) throws IOException {

    // 4. Compila
    public static void main(String... args) throws RuntimeException {

        int x = 0;
        System.out.println(7 / x);
    }

}
