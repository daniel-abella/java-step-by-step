package exception.herancaexception;

public class C4 extends C {

    public void doStuff(int x) throws Exception { // Sobrescrita v�lida, aumentando o n�vel de acesso.
    }
}
