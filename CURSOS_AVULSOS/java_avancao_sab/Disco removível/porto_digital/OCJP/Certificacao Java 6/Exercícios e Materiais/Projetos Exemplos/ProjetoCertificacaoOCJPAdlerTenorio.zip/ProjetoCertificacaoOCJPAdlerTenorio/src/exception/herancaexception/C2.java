package exception.herancaexception;

public class C2 extends C {

    @Override
    public void doStuff() throws SubSubException {
    }
}
