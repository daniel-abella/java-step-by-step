package exception.exemplo01;

public class Tire {

    void doStuff() {
    }

}
