package heranca.construtores;

public class Bottom2 extends Top {

	public Bottom2(String s) {
		super(s);
		System.out.println("D");
	}

	public static void main(String[] args) {
		new Bottom2("C");
		System.out.println("  ");
	}

}
