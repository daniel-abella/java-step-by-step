package heranca.interfaces3;

public interface IGo {
	
	public void go();

}
