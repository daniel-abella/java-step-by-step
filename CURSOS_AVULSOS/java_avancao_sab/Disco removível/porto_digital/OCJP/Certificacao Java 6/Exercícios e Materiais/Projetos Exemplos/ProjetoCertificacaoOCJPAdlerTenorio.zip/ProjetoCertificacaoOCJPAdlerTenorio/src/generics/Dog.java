package generics;

public class Dog extends Animal {

    public void latir() {
        System.out.println("owwwwwwwwwokdokwkow");
    }
}
