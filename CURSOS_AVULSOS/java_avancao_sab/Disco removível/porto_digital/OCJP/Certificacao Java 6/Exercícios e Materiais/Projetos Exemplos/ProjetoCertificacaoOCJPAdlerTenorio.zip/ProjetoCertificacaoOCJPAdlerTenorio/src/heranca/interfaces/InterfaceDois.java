package heranca.interfaces;
public interface InterfaceDois {

    boolean contem();
}
