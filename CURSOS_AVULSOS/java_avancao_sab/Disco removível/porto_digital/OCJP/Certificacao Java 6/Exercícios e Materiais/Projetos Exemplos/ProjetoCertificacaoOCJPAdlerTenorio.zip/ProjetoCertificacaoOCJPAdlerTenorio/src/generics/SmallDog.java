package generics;

public class SmallDog extends Dog {

}
