package heranca;

public class C extends B {
	
	public void x() {
		
	}
}
