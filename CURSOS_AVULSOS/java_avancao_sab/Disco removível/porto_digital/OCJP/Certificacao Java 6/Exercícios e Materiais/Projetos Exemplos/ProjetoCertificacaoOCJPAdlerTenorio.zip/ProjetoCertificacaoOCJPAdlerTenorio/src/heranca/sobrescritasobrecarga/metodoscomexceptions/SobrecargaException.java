package heranca.sobrescritasobrecarga.metodoscomexceptions;

public class SobrecargaException extends Exception {
	
	private static final long serialVersionUID = 1L;
	

}
