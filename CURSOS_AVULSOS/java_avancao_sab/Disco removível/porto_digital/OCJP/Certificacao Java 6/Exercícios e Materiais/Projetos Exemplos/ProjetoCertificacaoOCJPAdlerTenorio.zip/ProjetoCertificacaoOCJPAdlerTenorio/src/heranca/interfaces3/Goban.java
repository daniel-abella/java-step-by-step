package heranca.interfaces3;

public class Goban implements IGo{

	@Override
	public void go() {
		System.out.println("go in Goban");
	}
}
