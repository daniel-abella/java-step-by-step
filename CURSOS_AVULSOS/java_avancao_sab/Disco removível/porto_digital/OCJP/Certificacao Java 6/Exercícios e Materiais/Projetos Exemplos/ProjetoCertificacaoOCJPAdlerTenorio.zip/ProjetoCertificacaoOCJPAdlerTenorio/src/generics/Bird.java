package generics;

public class Bird extends Animal implements IZoologico {

}
