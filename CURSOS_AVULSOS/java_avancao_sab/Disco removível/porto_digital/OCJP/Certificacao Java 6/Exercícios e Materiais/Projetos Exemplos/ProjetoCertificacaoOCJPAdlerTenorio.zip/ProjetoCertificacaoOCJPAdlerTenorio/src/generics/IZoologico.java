package generics;

public interface IZoologico {

}
