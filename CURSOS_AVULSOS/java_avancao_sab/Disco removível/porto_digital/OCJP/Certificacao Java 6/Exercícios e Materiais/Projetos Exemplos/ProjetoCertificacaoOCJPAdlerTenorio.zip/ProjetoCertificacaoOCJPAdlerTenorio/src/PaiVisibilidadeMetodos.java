public class PaiVisibilidadeMetodos {

	public void imprimirPai() {
		System.out.println("imprimirPai");
	}

	public void naoImprimirPai() {
		System.out.println("N�o imprimirPai");
	}

}
