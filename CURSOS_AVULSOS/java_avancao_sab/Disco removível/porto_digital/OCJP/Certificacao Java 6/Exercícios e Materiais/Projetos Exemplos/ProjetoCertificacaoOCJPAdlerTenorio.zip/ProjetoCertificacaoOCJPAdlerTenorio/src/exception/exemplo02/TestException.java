package exception.exemplo02;

public class TestException extends Exception{
	
	

}
