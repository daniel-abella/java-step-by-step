package br.com.qualiti.javaio.modelo;

public class Cliente {

}
