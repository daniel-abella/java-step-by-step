package listararquivos;

import java.util.Calendar;
import java.util.Date;

public final class FunctionsUtils {

	public Date dateFromMilliseconds(long dateMilliseconds){

		//Calendar calendar = Calendar.getInstance();
		//calendar.setTimeInMillis(dateMilliseconds);

		return null;//calendar.getTime();
	}

}